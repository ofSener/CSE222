package devices;

/*
I keep it to look devices' on off situation.
with the methods i ll change the state.
 */
public enum State {
    ON,
    OFF
}
